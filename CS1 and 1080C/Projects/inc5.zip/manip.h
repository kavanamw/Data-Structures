#ifndef MANIP_H
#define MANIP_H

// Author: Fill in your name
// Source File: manip.h
// Description: A set of functions where you should manipulate
// the passed parameters to change the object in a specific way, 
// so that Pointers_test.h passes all tests.

#include "Pointers.h"

// A little something to get you going
void manip1(Pointers* p){
  *(p->getA()) = 10;
}

void manip2(Pointers* p){
  // TODO: Fill me in
}

void manip3(Pointers* p){
  // TODO: Fill me in
}

void manip4(Pointers* p, int* other){
  // TODO: Fill me in
}

void manip5(Pointers* p, int* other){
  // TODO: Fill me in
}

void manip6(Pointers* p){
  // TODO: Fill me in
}

void manip7(Pointers* p){
  // TODO: Fill me in
}

void manip8(Pointers* p){
  // TODO: Fill me in
}

void manip9(Pointers* p, int* other){
  // TODO: Fill me in
}

void manip10(Pointers* p){
  // TODO: Fill me in
}

#endif
